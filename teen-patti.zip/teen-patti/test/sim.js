// Simulates 60 players playing several rounds with random actions and exchanges.
const { io } = require('socket.io-client');
const URL = 'http://localhost:' + (process.env.PORT || 3000);
const N = 60; const bots = [];
let rounds = 0, lastRound = 0, errors = {}, shows = 0, swaps = 0, ex = 0;
const sleep = ms => new Promise(r => setTimeout(r, ms));
function bot(i) {
  return new Promise(res => {
    const s = io(URL, { transports: ['websocket'], forceNew: true });
    const b = { s, st: null, name: 'Bot' + i, busy: false };
    s.on('connect', () => s.emit('join', { name: b.name }, r => { b.id = r.id; res(b); }));
    s.on('state', st => { b.st = st; think(b); });
  });
}
const emit = (b, a) => new Promise(r => b.s.emit('action', a, x => { if (!x.ok) errors[x.error] = (errors[x.error]||0)+1; r(x); }));
async function think(b) {
  const st = b.st; if (!st || !st.round || b.busy) return;
  const inc = st.swaps.find(s => s.incoming);
  if (inc) { b.busy = true; await emit(b, { type: 'swap-reply', requestId: inc.id, accept: Math.random() < .6, index: Math.floor(Math.random()*3) }); swaps++; b.busy = false; return; }
  if (st.round.turn !== b.id) return;
  b.busy = true; await sleep(5);
  const me = st.me, r = Math.random();
  if (!me.seen && r < .5) await emit(b, { type: 'see' });
  const st2 = b.st;
  if (st2.me.seen && st2.me.exchangesLeft > 0 && Math.random() < .3) {
    const k = Math.random();
    if (k < .4) { await emit(b, { type: 'exchange-one', index: Math.floor(Math.random()*3) }); ex++; }
    else if (k < .7) { await emit(b, { type: 'exchange-all' }); ex++; }
    else { const t = st2.players.filter(p => p.inRound && !p.packed && p.id !== b.id); if (t.length) await emit(b, { type: 'swap-request', to: t[0].id, index: 0 }); }
  }
  const st3 = b.st;
  if (st3.round && st3.round.turn === b.id) {
    if (st3.round.active === 2 && Math.random() < .5) { await emit(b, { type: 'show' }); shows++; }
    else if (Math.random() < .35 || st3.round.active > 2 && Math.random() < .2) await emit(b, { type: 'pack' });
    else await emit(b, { type: 'chaal', raise: Math.random() < .15 });
  }
  b.busy = false;
}
(async () => {
  for (let i = 0; i < N; i++) bots.push(await bot(i));
  const host = bots[0];
  await sleep(300);
  host.s.emit('host', { type: 'settings', settings: { turnSeconds: 10, autoNext: false } }, () => {});
  console.log('players joined:', host.st.players.length);
  const total0 = host.st.players.reduce((a, p) => a + p.chips, 0);
  for (let k = 0; k < 15; k++) {
    const sr = await new Promise(r => host.s.emit('host', { type: 'start' }, r)); if (!sr.ok) { console.log('start failed', sr); process.exit(1); } await sleep(100);
    const t0 = Date.now();
    while (host.st.round && Date.now() - t0 < 60000) { await sleep(50); for (const b of bots) if (b.st?.round?.turn === b.id) think(b); }
    if (host.st.round) { console.log('round stuck', host.st.round); process.exit(1); }
    rounds++;
    const total = host.st.players.reduce((a, p) => a + p.chips, 0);
    const rebuys = host.st.players.reduce((a, p) => a + p.rebuys, 0);
    if (total !== total0 + rebuys * 1000) { console.log('CHIP MISMATCH', total, total0); process.exit(1); }
    for (const b of bots) if (b.st.me.chips < 40) b.s.emit('rebuy', () => {});
    await sleep(200);
    console.log(`round ${host.st.lastResult.no}: ${host.st.lastResult.text.slice(0, 110)}`);
  }
  console.log({ rounds, shows, swaps, exchanges: ex, errors });
  process.exit(0);
})();
