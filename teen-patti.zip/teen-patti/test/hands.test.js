const { compare, evaluate } = require('../game/hands');
const P = s => s.split(' ').map(t => { const suit=t.slice(-1); let r=t.slice(0,-1); r={J:11,Q:12,K:13,A:14}[r]||+r; return {r,s:suit}; });
const cases = [
  ['A S A H A D', 'A S K S Q S', 1, 'trail > pure seq'],
  ['A S K S Q S', 'A H 2 H 3 H'.replace(/ /g,''), 0, 'skip'],
];
let fail=0; const ok=(c,m)=>{ if(!c){fail++;console.log('FAIL',m);} };
const cmp=(a,b)=>Math.sign(compare(P(a),P(b)));
ok(cmp('AS AH AD','AS KS QS')===1,'trail beats pure seq');
ok(cmp('2S 2H 2D','AS KS QS')===1,'lowest trail beats top pure seq');
ok(cmp('AS KS QS','AH 2H 3H')===1,'AKQ > A23');
ok(cmp('AH 2H 3H','4S 3S 2S')===-1,'A23 lowest pure seq');
ok(cmp('4H 3S 2D','AH 2S 3D')===1,'432 > A23 seq');
ok(evaluate(P('KS AH 2D')).cat===1,'KA2 not seq');
ok(cmp('2S 3S 4H','AS KS 9S')===1,'seq > colour');
ok(cmp('AS KS 9S','AH AD KC')===1,'colour > pair');
ok(cmp('2H 2D 3C','AS KD JC')===1,'pair > high');
ok(cmp('KH KD 2C','QH QD AC')===1,'pair rank first');
ok(cmp('KH KD 5C','KS KC 4C')===1,'pair kicker');
ok(cmp('AS KD JC','AH KC JD')===1,'suit tiebreak spade');
ok(cmp('AS KD JC','AS KD JC')===0,'identical (5 decks)');
ok(evaluate(P('AH 2H 3H')).cat===5,'A23 pure seq');
console.log(fail?`${fail} failed`:'all hand tests passed');
